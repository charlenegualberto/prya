package com.saude.prya

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.Image
import android.os.Parcel
import android.os.Parcelable
import android.provider.ContactsContract

class DatabaseHelper (context: Context):SQLiteOpenHelper(context, dbname, factory, version) {
    companion object{
        internal val dbname = "BancoPrya"
        internal val factory = null
        internal val version = 1
    }

    override fun onCreate(p0: SQLiteDatabase?) {
        p0?.execSQL("create table usuario (id integer primary key autoincrement," +
                "name varchar(50), email varchar(100), date varchar(11), photo blob, sex integer," +
                "password varchar(20))")
    }

    fun insereUsuario(name: String, email: String, date: String,
                      photo: ByteArray, sex: Int, password: String){
        val db: SQLiteDatabase = writableDatabase
        val values: ContentValues = ContentValues()
        values.put("name", name)
        values.put("email", email)
        values.put("date", date)
        values.put("photo", photo)
        values.put("sex", sex)
        values.put("password", password)

        db.insert("usuario", null, values)
        db.close()
    }

    fun presentUsuario(email: String, pass: String): Boolean{
        val db = writableDatabase
        val query = "SELECT * FROM usuario WHERE email = '$email' AND password = '$pass'"
        val cursor = db.rawQuery(query, null)
        cursor?.moveToFirst()
        if (cursor.count <= 0) {
            cursor.close()
            return false
        }
        cursor.close()
        return true
    }

    fun mostraUsuario(email: String): Usuario{
        var usuarioAtual = Usuario()
        val db = this.readableDatabase
        val query = "SELECT * FROM usuario WHERE email = '$email'"
        val cursorretornado = db.rawQuery(query,null)
        cursorretornado?.moveToFirst()
        usuarioAtual.nome_usu = cursorretornado.getString(cursorretornado.getColumnIndex("name"))
        usuarioAtual.email_usu = cursorretornado.getString(cursorretornado.getColumnIndex("email"))
        usuarioAtual.data_usu = cursorretornado.getString(cursorretornado.getColumnIndex("date"))
        usuarioAtual.imagem_usu = cursorretornado.getBlob(cursorretornado.getColumnIndex("photo"))
        usuarioAtual.sexo_usu = cursorretornado.getInt(cursorretornado.getColumnIndex("sex"))
        usuarioAtual.senha_usu = cursorretornado.getString(cursorretornado.getColumnIndex("password"))

        return usuarioAtual
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        val DROP_TABLE = "DROP TABLE IF EXISTS usuario"
        p0?.execSQL(DROP_TABLE)
        onCreate(p0)
    }

}