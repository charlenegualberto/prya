package com.saude.prya

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.forgoted_password.*
import kotlinx.android.synthetic.main.user_registration.*

class LoginActivity : AppCompatActivity() {

    lateinit var handler: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        handler = DatabaseHelper(this)



        facebook_button.setOnClickListener{
            Toast.makeText(applicationContext, "Logando com o Facebook", Toast.LENGTH_SHORT).show()
            openNextActivity()
        }

        google_button.setOnClickListener{
            Toast.makeText(applicationContext, "Logando com o Google", Toast.LENGTH_SHORT).show()
            openNextActivity()
        }

        login.setOnClickListener{
            if(handler.presentUsuario(email_login.text.toString(), password_login.text.toString())) {
                Toast.makeText(applicationContext, "Logado com sucesso!", Toast.LENGTH_SHORT).show()
                openNextActivity()
            }
            else {
                Toast.makeText(applicationContext, "Senha ou Email incorretos", Toast.LENGTH_SHORT).show()
            }
        }

        forgotedpass.setOnClickListener{
            showForgotedPass()
        }

        registration.setOnClickListener{
            showRegistration()
        }

        button_recuperar.setOnClickListener{
            Toast.makeText(applicationContext, "Senha enviada para recuperação", Toast.LENGTH_SHORT).show()
            showLogin()
        }

        button_camera.setOnClickListener{

        }

        button_galeria.setOnClickListener{

        }

        button_registar.setOnClickListener{
            var sexo_reg = 0
            if(rad_f.isChecked){
                sexo_reg = 1
            } else if (rad_m.isChecked){
                sexo_reg = 2
            }

            handler.insereUsuario(name_reg.text.toString(), email_reg.text.toString(),
                date_reg.text.toString(), byteArrayOf(R.drawable.usuario.toByte()), sexo_reg.toInt() ,password_reg.text.toString()
            )
            Toast.makeText(applicationContext, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
            showLogin()
        }
    }

    private fun showRegistration(){
        layout_registration.visibility = View.VISIBLE
        layout_login.visibility = View.GONE
        layout_recuperar.visibility = View.GONE
    }

    private fun showForgotedPass(){
        layout_recuperar.visibility = View.VISIBLE
        layout_login.visibility = View.GONE
        layout_registration.visibility = View.GONE
    }

    private fun showLogin(){
        layout_login.visibility = View.VISIBLE
        layout_registration.visibility = View.GONE
        layout_recuperar.visibility = View.GONE
    }

    private fun openNextActivity(){
        val intent = Intent(this, MenuActivity::class.java)
        startActivity(intent)
    }

}