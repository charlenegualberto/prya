package com.saude.prya

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_historico.*
import kotlinx.android.synthetic.main.activity_login.*

class HistoricoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historico)

        calendario.setOnClickListener{
            showDia()
        }

    }
    private fun showDia(){
        view_historico.visibility = View.GONE
        ver_dia.visibility = View.VISIBLE
    }
}