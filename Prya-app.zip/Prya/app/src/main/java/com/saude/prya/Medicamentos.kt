package com.saude.prya

data class Medicamentos (
    val nome_medi: String,
    val frequecia_med: String,
    val quanti_estoque: Int,
    val horarios: String
)