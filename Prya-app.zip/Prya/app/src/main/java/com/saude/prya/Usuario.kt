package com.saude.prya

import java.lang.reflect.Constructor

data class Usuario (
    var nome_usu: String = "",
    var email_usu: String = "",
    var data_usu: String = "",
    var imagem_usu: ByteArray = byteArrayOf(),
    var sexo_usu: Int = 0,
    var senha_usu: String = ""
)