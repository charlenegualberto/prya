package com.saude.prya

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DicasActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dicas)
    }
}