package com.saude.prya

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import androidx.viewpager.widget.PagerAdapter
import kotlinx.android.synthetic.main.activity_medicamento.*
import kotlinx.android.synthetic.main.activity_medicamento.view.*
import kotlinx.android.synthetic.main.alarmes_conteudo.view.*
import kotlinx.android.synthetic.main.medicamentos_conteudo.view.*
import kotlinx.android.synthetic.main.tip_content.view.*

class MedicamentoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_medicamento)

        val medicamentos = arrayOf(
            Medicamentos(
                "Resflenol",
                "Semanalmente",
                12,
                "12h"
            ),
            Medicamentos(
                "Dipirona",
                "Dias alternados",
                10,
                "12h"
            ),
            Medicamentos(
                "AAS",
                "Diariamente",
                12,
                "10h e 22h"
            )
        )

        val listMed = findViewById<ListView>(R.id.list_medicamentos)
        listMed.adapter = listAdapter(this, medicamentos)

        val listHorario = findViewById<ListView>(R.id.list_horario)
        listHorario.adapter = listAdapterHorario(this, medicamentos)

        button_addMedicine.setOnClickListener(){
            openNextActivity()
        }
    }


    private class listAdapter(context: Context, medica: Array<Medicamentos>) : BaseAdapter() {

        private val medicines: Context

        val medicamentos = medica

        init {
            medicines = context
        }

        override fun getItem(p0: Int): Any {
            TODO("Not yet implemented")
        }

        override fun getItemId(p0: Int): Long {
            TODO("Not yet implemented")
        }

        override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
            val layoutInflater = LayoutInflater.from(medicines)

            //enchendo a lista de medicamentos
            val conteudo = layoutInflater.inflate(R.layout.medicamentos_conteudo, p2, false)
            conteudo.medicamento_nome.text = medicamentos.get(p0).nome_medi
            conteudo.frequencia_uso.text = medicamentos.get(p0).frequecia_med
            conteudo.quant_estoque.text = medicamentos.get(p0).quanti_estoque.toString()

            return conteudo
        }

        override fun getCount(): Int {
            return medicamentos.size
        }
    }

    private class listAdapterHorario(context: Context, medica: Array<Medicamentos>) : BaseAdapter() {

        private val medicines: Context

        val medicamentos = medica

        init {
            medicines = context
        }

        override fun getItem(p0: Int): Any {
            TODO("Not yet implemented")
        }

        override fun getItemId(p0: Int): Long {
            TODO("Not yet implemented")
        }

        override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
            val layoutInflater = LayoutInflater.from(medicines)

            //enchendo a lista de medicamentos
            val conteudo = layoutInflater.inflate(R.layout.alarmes_conteudo, p2, false)
            conteudo.medicamento_nome2.text = medicamentos.get(p0).nome_medi
            conteudo.horario.text = medicamentos.get(p0).horarios

            return conteudo
        }

        override fun getCount(): Int {
            return medicamentos.size
        }
    }

    private fun openNextActivity(){
        val intent = Intent(this, AddMedicineActivity::class.java)
        startActivity(intent)
    }
}