package com.saude.prya

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_menu.*

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        button_howtoday.setOnClickListener {
            openHowtodayActivity()
        }

        button_medicamentos.setOnClickListener {
            openMedicamentoActivity()
        }

        button_exames.setOnClickListener {
            openExamesActivity()
        }

        button_historico.setOnClickListener {
            openHistoricoActivity()
        }

        button_consultas.setOnClickListener {
            openConsultasActivity()
        }

        button_informacoes.setOnClickListener {
            openInformacoesActivity()
        }

        button_dicas.setOnClickListener {
            openDicasActivity()
        }

        button_configuracoes.setOnClickListener {
            openConfiguracoesActivity()
        }
    }

    private fun openMedicamentoActivity(){
        val intent = Intent(this, MedicamentoActivity::class.java)
        startActivity(intent)
    }

    private fun openHowtodayActivity(){
        val intent = Intent(this, HowtodayActivity::class.java)
        startActivity(intent)
    }

    private fun openExamesActivity(){
        val intent = Intent(this, ExamesActivity::class.java)
        startActivity(intent)
    }

    private fun openHistoricoActivity(){
        val intent = Intent(this, HistoricoActivity::class.java)
        startActivity(intent)
    }

    private fun openConsultasActivity(){
        val intent = Intent(this, ConsultasActivity::class.java)
        startActivity(intent)
    }

    private fun openInformacoesActivity(){
        val intent = Intent(this, InformacoesActivity::class.java)
        startActivity(intent)
    }

    private fun openDicasActivity(){
        val intent = Intent(this, DicasActivity::class.java)
        startActivity(intent)
    }

    private fun openConfiguracoesActivity(){
        val intent = Intent(this, ConfiguracoesActivity::class.java)
        startActivity(intent)
    }

}